# McTrainer Tier Tracker for Discord

Tracks tier labels found on the public profile for `ScarySne487453` and sends Discord webhook announcements when a previously tracked label changes.

## Important limitation

This package includes a best-effort HTML parser, not a confirmed McTrainer-specific parser. I could not verify the profile's live HTML structure or a public API in this session. If the site renders tier data in JavaScript or uses a different layout, the first workflow run may report `No tier labels were found`; `extract_tiers()` will then need adapting to the actual page/API.

The current parser detects labels matching `LT5` through `HT1`. It announces any detected tier-label change, including a possible demotion; it does not yet determine tier ordering.

## Setup

1. Create a GitHub repository (private is recommended).
2. Upload `tracker.py`, `requirements.txt`, and `.github/workflows/tracker.yml`, preserving the workflow's folder path.
3. In your Discord server, go to **Server Settings → Integrations → Webhooks**, create a webhook for the announcement channel, and copy its URL.
4. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**.
   - Name: `DISCORD_WEBHOOK_URL`
   - Value: your copied Discord webhook URL
5. In **Settings → Actions → General → Workflow permissions**, allow read/write access to repository contents if needed.
6. Open **Actions → McTrainer Tier Tracker → Run workflow**.
7. The first successful run saves a baseline and does not announce existing tiers. Later runs compare against that baseline.
8. Check the run logs. If parsing succeeds, `state.json` is committed automatically.

## Files

- `tracker.py`: fetches the profile, parses tier labels, compares state, and posts announcements.
- `requirements.txt`: dependencies.
- `.github/workflows/tracker.yml`: runs on a schedule every 15 minutes (GitHub scheduling is best-effort) and supports manual runs.

Keep your webhook URL secret. Anyone with it may be able to post to the channel.

import json
import os
import re
import sys
from pathlib import Path

import requests
from bs4 import BeautifulSoup

PROFILE_URL = "https://mctrainer.club/players/ScarySne487453"
WEBHOOK_URL = os.environ["DISCORD_WEBHOOK_URL"]
STATE_FILE = Path("state.json")

# Starter pattern for common McTrainer tier labels.
TIER_RE = re.compile(r"\b(?:LT|HT)[1-5]\b", re.I)

session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (compatible; McTrainerTierTracker/1.0)"
})


def fetch_profile():
    response = session.get(PROFILE_URL, timeout=30)
    response.raise_for_status()
    return response.text


def extract_tiers(html):
    """Best-effort HTML parser; may need adapting if tiers are JavaScript-rendered."""
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(["script", "style", "noscript", "svg", "template"]):
        tag.decompose()

    found = {}

    # Try table rows first.
    for row in soup.select("tr"):
        text = " ".join(row.stripped_strings)
        for match in TIER_RE.finditer(text):
            label = text[:match.start()].strip(" :-|")
            if label:
                found[label] = match.group().upper()

    # Fallback: look at visible text lines and use the preceding line as a label.
    if not found:
        lines = [
            line.strip()
            for line in soup.get_text("\n").splitlines()
            if line.strip()
        ]
        for i, line in enumerate(lines):
            for match in TIER_RE.finditer(line):
                label = line[:match.start()].strip(" :-|")
                if not label and i > 0:
                    label = lines[i - 1]
                if label:
                    found[label] = match.group().upper()

    return found


def load_state():
    if not STATE_FILE.exists():
        return None
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        raise RuntimeError(
            "state.json could not be read; refusing to reset the saved baseline."
        ) from exc


def save_state(tiers):
    STATE_FILE.write_text(
        json.dumps(tiers, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def announce(label, old_tier, new_tier):
    payload = {
        "username": "McTrainer Tier Tracker",
        "embeds": [{
            "title": "🎉 Tier changed!",
            "description": (
                "**Player:** ScarySne487453\n"
                f"**Category / mode:** {label}\n"
                f"**Previous tier:** {old_tier}\n"
                f"**New tier:** {new_tier}\n\n"
                f"[View profile]({PROFILE_URL})"
            ),
            "color": 0x57C785,
        }],
        "allowed_mentions": {"parse": []},
    }

    response = session.post(WEBHOOK_URL, json=payload, timeout=20)
    response.raise_for_status()


def main():
    html = fetch_profile()
    current = extract_tiers(html)

    if not current:
        raise RuntimeError(
            "No tier labels were found. The profile may be JavaScript-rendered "
            "or the HTML parser may need adapting. Existing state was not changed."
        )

    previous = load_state()

    if previous is None:
        save_state(current)
        print(
            f"Saved initial baseline with {len(current)} tier entries. "
            "No announcements sent on the first run."
        )
        return

    updated = dict(previous)
    changes = []

    for label, new_tier in current.items():
        old_tier = previous.get(label)

        if old_tier is None:
            # Newly discovered categories are added silently, not announced as upgrades.
            updated[label] = new_tier
        elif old_tier != new_tier:
            changes.append((label, old_tier, new_tier))
            updated[label] = new_tier

    # Send before saving, so failed webhook requests can be retried next run.
    for label, old_tier, new_tier in changes:
        announce(label, old_tier, new_tier)
        print(f"Announced {label}: {old_tier} -> {new_tier}")

    save_state(updated)
    print(f"Checked {len(current)} tier entries; detected {len(changes)} change(s).")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Tracker failed: {exc}", file=sys.stderr)
        sys.exit(1)
